from math import sqrt, factorial

print(sqrt(16))
print(factorial(6))

from math import *    #importing all names

print(sqrt(19))
print(factorial(9))
