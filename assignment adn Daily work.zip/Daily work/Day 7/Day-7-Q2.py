#2) [[4,5,3], [6,3,2],[6,9,1]]    output = [12, 11, 16]
list = [[4, 5, 3], [6, 3, 2], [6, 9, 1]]
res = [sum(x) for x in list]
print(res)