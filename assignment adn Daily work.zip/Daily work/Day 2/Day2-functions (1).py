def sum(a,b):
    c=a+b
    return(c)
a=int(input('enter the value of a: '))
b=int(input('enter the value of b: '))
print(sum(a,b))