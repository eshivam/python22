print('for loop')
for x in range(5):
    print(x)
    
print('while loop')
x=1
while x < 5:
    print(x)
    x+=1