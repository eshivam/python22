string = "Utkrisht"
print(string.startswith("Utk"))