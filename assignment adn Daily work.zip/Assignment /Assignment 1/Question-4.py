mystr="hello"
x = mystr.replace( "e" , "$")
print(x)