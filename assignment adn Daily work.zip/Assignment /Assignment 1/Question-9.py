mystr="welcome"
n =3
x= mystr[:n-1] + mystr[n:]
print(x)