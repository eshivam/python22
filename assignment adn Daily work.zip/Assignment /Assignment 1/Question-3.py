mystr="hello"
if len(mystr) > 1:
    print(mystr[:2]+mystr[-2:])
else:
    print("empty string")