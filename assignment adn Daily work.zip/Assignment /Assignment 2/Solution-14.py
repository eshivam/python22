#Min of list
numbers = [6, 5, 3, 8, 4, 2, 5, 6, 11]
x = min(numbers)
print(x)