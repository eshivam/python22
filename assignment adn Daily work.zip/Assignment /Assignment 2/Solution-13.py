#Max of list
numbers = [6, 5, 3, 8, 4, 2, 5, 6, 11]
x = max(numbers)
print(x)