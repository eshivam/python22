#reverse a list
a=[5,"ram",10,"ravi",3]
a.reverse()
print(a)